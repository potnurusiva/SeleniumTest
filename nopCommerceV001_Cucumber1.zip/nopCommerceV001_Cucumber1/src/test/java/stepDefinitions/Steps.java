package stepDefinitions;
import com.opencsv.exceptions.CsvException;
import io.cucumber.java.en.*;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import pageObjects.LoginPage;
import java.io.IOException;
import java.time.Duration;
import java.util.logging.Logger;

public class Steps {
    public WebDriver driver;
    LoginPage lp;
    public static Logger logger;
    @Given("User launch chrome browser")
    public void Userlaunchchromebrowser() {
        String path = System.getProperty("user.dir");
        System.setProperty("webdriver.chrome.driver", "" + path + "/Drivers/chromedriver_mac_arm64/chromedriver");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");
        options.addArguments("--remote-allow-origins=*");
        driver=new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
    }

    @When("user opens url")
    public void userOpensUrl() {
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        driver.manage().window().maximize();
    }

    @And("user enters username as {string} and password as {string}")
    public void userEntersUsernameAsAndPasswordAs(String user, String pwd) {
        lp=new LoginPage(driver);
        lp.setUserName_password(user,pwd);
    }

    @And("click on Login button")
    public void clickOnLoginButton() {
        lp.clickonLogin();
    }

    @Then("After logging in, mouse hover to PIM and click")
    public void afterLoggingInMouseHoverToPIMAndClick() throws InterruptedException {
        lp.clickOnPIM();
    }

    @And("In the PIM page, click on Add Employee")
    public void inThePIMPageClickOnAddEmployee() {
        lp.clickOnAddEmployee();
    }

    @Then("Add employees using Data Driven Testing from a csv sheet")
    public void addEmployeesUsingDataDrivenTestingFromACsvSheet() throws IOException, CsvException, InterruptedException {
        lp.enterEmployeeDetails();
    }

    @And("After Adding go to the Employee List page")
    public void afterAddingGoToTheEmployeeListPage() {
        lp.clickOnEmployeeList();
    }

    @Then("Scroll and look for the employees added and verify with name")
    public void scroll_and_look_for_the_employees_added_and_verify_with_name() {
        lp.verifyAddedEmployeeNames();
    }

    @Then("Logout from the dashboard")
    public void logoutFromTheDashboard() {
        lp.clickLogout();
    }

    @And("close browser")
    public void closeBrowser() {
        driver.quit();
    }

}
